# PACKAGE_INDEX — FigEllis_Starter_UI_Kit_v0.1a
- index.html
- account.html
- library.html
- styles.css
- README_FOR_HUMANS.md
- manifest.txt

Notes:
- Complies with Visual Gate System v1.0
- Hex-Literal Enforcement active

- integrity.html

- subscribe.html

- tiers.html
- changelog.html

- 404.html
